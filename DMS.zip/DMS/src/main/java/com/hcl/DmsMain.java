/*
 *Created By: Sample
 * Copyright &copy; 2015. Abhinav Kumar Mishra.
 * All rights reserved.
 *
 *  Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *     http://www.apache.org/licenses/LICENSE-2.0 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
package com.hcl;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import com.hcl.util.DmsUtil;
/**
 * The Class SampleMain.
 */
public class DmsMain {
/**
* Object for logger.
*/
private static final Logger LOGGER
= LoggerFactory.getLogger(DmsMain.class);
/**
* Main Method to execute the Project.
* @param varargs is a string variable
*/
public static void main(final String[] varargs) {
//System.out.println("Hello world with Checkstyle and PMD");
// LOGGER.info("Hello world with Checkstyle and PMD");
final DmsUtil util = new DmsUtil();
util.pirnt();
final DmsMain obmain = new DmsMain();
obmain.dummy();
}
/**
* Dummy Method to Sum.
*/
public final void dummy() {
LOGGER.info("Inside the dummy function");
final int number1 = 10;
final int number2 = 2;
final int number3 = number1 + number2;
final String string = "The sum of two numbers:";
LOGGER.info(string + number3);
}
}
